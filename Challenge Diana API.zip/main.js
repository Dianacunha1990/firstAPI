const { Calculadora } = require("./services/coisas");
const express = require("express");
const app = express();
const port = 3000;
app.use(express.json());


// Os 9 endpoints são:

// POST /op/potencia
// POST /op/somar
// POST /op/subtrair
// POST / op / multiplicar
// POST /op/dividir
// POST /repetir
// DELETE /
// GET /ultimo-resultado
// GET /


// app.post("/soma", (req, res) => {
//   const { a, b } = req.body;
//   res.status(200).json({ resultado: a + b });
// });

// const calc = new { a, b } = req.body;
const calc = new Calculadora()

// calc.somar(req.body.a, req.body.b)

// app.post("/soma", (req, res) => {
//   const { a, b } = req.body;
//   res.status(200).json({ resultado: calc.somar(req.body.a, req.body.b) });
// });

// app.post("/op/potencia", (req, res) => {
//     const { a, b } = req.body;
//     res.status(200).json({ resultado: a ** b });
// });

app.post("/op/potencia", (req, res) => {
  const { a, b } = req.body;
  if (isNaN(a) || isNaN(b)) {
    return res.status(400).send({ erro: "Argumentos Inválidos" });
  }

  const resultado = calc.potencia(a, b);
  res.send({ resultado });
});

app.post("/op/somar", (req, res) => {
  const { a, b } = req.body;
  if (isNaN(a) || isNaN(b)) {
    return res.status(400).json({ erro: "Argumentos Inválidos" });
  }
  const resultado = calc.somar(a, b);
  res.send({ resultado });
});

app.post("/op/subtrair", (req, res) => {
    const { a, b } = req.body;
     if (isNaN(a) || isNaN(b)) {
       return res.status(400).json({ erro: "Argumentos Inválidos" });
     }
  const resultado = calc.subtrair(a, b);
  res.send({ resultado });
});


app.post("/op/dividir", (req, res) => {
    const { a, b } = req.body;
     if (isNaN(a) || isNaN(b)) {
       return res.status(400).json({ erro: "Argumentos Inválidos" });
     }    
  const resultado = calc.dividir(a, b);
  res.send({ resultado });
});

app.post("/op/multiplicar", (req, res) => {
    const { a, b } = req.body;
     if (isNaN(a) || isNaN(b)) {
       return res.status(400).json({ erro: "Argumentos Inválidos" });
     }
  const resultado = calc.multiplicar(a, b);
  res.send({ resultado });
});

app.delete("/", (req, res) => {
  res.send(calc.limparHistorico());
});

app.post("/repetir", (req, res) => {

    const { num } = req.body;
    if (isNaN(num) ) {
        return res.status(400).json({ erro: "Argumentos Inválidos" })
    }
    if (calc.historico.length > 0) {
        const buscar = calc.historico[calc.historico.length - 1]
        const simbolo = buscar.split(" ")[1]
         res.status(200).json(calc.aplicaOperacao(num, undefined, simbolo));

    } else {
        res.status(400).json({erro: " Histórico vazio"});
        
        
}


} )



app.get("/", (req, res) => {
  res.send({ historico: calc.historico });
});
app.get("/ultimo-resultado", (req, res) => {
  const resultado = calc.obterResultado();
  res.send({ resultado });
});

app.post("/op", (req, res) => {
  const { op } = req.body;
  const resultado = calc.aplicaOperacao(op);
  res.send({ resultado });
});



















app.listen(port, () => {
  console.log(`À escuta em http://localhost:${port}`);
});